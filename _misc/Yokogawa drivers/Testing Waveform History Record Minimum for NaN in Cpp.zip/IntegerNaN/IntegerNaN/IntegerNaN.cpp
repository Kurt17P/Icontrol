// IntegerNaN.cpp : main project file.

#include "stdafx.h"
#include "tmctl.h"

using namespace System;

int main(array<System::String ^> ^args)
{
    Console::WriteLine("Testing for Integer.NaN");

	int  ret;
	int  id;
	char buf[1000];
	int  length;

	// Example 5: USBTMC(DL9000) Serial Number = 27E000001
	ret = TmcInitialize( TM_CTL_USBTMC, "27E826755", &id );

	/* get number of valid waveforms */
	ret = TmcSend( id, ":WAVeform:RECord? MINimum" );
	if( ret != 0 ) {
		return	TmcGetLastError( id );
	}

	ret = TmcReceive( id, buf, 1000, &length );
	if( ret != 0 ) {
		return	TmcGetLastError( id );
	}

	Console::WriteLine("The answer to :WAVeform:RECord? MINimum is");
	Console::WriteLine( gcnew String(buf) );
	
	// set a breakpoint and check buf
	Console::ReadLine();
	return ret;
}
