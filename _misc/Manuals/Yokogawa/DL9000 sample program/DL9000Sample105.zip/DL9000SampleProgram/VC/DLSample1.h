// DLSample1.h : DLSample1.cpp�p�̃w�b�_�[ �t�@�C���ł��B
//

#if !defined(___DLSAMPLE1_)
#define ___DLSAMPLE1_

#include "tmctl.h"

// Tmc Library Status
#define	CTL_OK				0
#define	CTL_ERROR			1
#define	CTL_OTHER			2
// Measure Error Message
#define	MEAS_NOT_TRIG		3
#define	MEAS_NOT_FIN		4

#define	TERM_CRLF			0
#define	TERM_CR				1
#define	TERM_LF				2
#define	TERM_EOI			3

#define	SET_TRUE			1
#define	SET_FALSE			0

#define	RUNTIME_COMMON_HEADER_SIZE	10
#define	RUNTIME_TRACE_HEADER_SIZE	16
#define RUNTIME_HEADER_SIZE			(RUNTIME_COMMON_HEADER_SIZE+RUNTIME_TRACE_HEADER_SIZE)

//Temporary Query Max Buffer Size
#define	TEMP_BUFF_SIZE		100
#define	TEMP_DATA_LENGTH	126000

// Grobal Variable
extern	int		StartFlag;							// Start Flag
extern	int		Dev;								// Device ID
extern	short	WaveBuffer[TEMP_DATA_LENGTH];		// WaveData Buffer(WORD)
extern	char	WaveBufferB[TEMP_DATA_LENGTH];		// WaveData Buffer(BYTE)

// Grobal Function
extern	int	InitDevice( int, char* );
extern	void CloseDevice( void );
extern	void DisplayError( int );
extern	int GetTdiv( char* );
extern	int GetWord( char [][TEMP_BUFF_SIZE], int* );
extern	int GetByte( char [][TEMP_BUFF_SIZE], int* );
extern	int GetMeasure( char [][TEMP_BUFF_SIZE] );
extern	int PresetToGetWordRuntime(void);
extern	int CheckDL6000_DLM6000( void );
extern	int GetWordRuntime( char lst[][TEMP_BUFF_SIZE], int* cnt );

#endif	// !defined(___DLSAMPLE1_)
