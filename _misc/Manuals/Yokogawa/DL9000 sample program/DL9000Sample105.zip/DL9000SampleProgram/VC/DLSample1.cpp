// SampleDlg.cpp : �C���v�������e�[�V���� �t�@�C��
//

#include "stdafx.h"
#include "DLSample1.h"

int		StartFlag;									// Start Flag
int		Dev;										// Device ID
short	WaveBuffer[TEMP_DATA_LENGTH];				// WaveData Buffer(WORD)
char	WaveBufferB[TEMP_DATA_LENGTH];				// WaveData Buffer(BYTE)

int	InitDevice( int wire, char* address )
{
	int		eos;									// EOS
	int		eot;									// EOI
	int		timeout;								// Timeout
	int		sts;

	eos = TERM_LF;									// Terminator = LF
	eot = SET_TRUE;									// EOI = Enable
	timeout = 100;									// Timeout = 10s

	sts = TmcInitialize( wire, address, &Dev );		// Initialize
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	sts = TmcDeviceClear( Dev );					// Device Clear(Only GPIB)
	if( CTL_OK != sts ){
		DisplayError( Dev );
		CloseDevice();								// Device Clear
		return sts;
	}

	sts = TmcSetTerm( Dev, eos, eot );				// Terminator = LF, EOI = Enable
	if( CTL_OK != sts ){
		DisplayError( Dev );
		CloseDevice();								// Device Clear
		return sts;
	}

	sts = TmcSetTimeout( Dev, timeout );			// Timeout = 10s
	if( CTL_OK != sts ){
		DisplayError( Dev );
		CloseDevice();								// Device Clear
		return sts;
	}
	return sts;
}

void CloseDevice( void )
{
	TmcFinish( Dev );
	Dev = -1;
}

void DisplayError( int id )
{
	char	*ers;
	int		err;
	CString	errMes;

	err = TmcGetLastError( id );					// Get Error No.
	if( 2 == err )
		ers = "Device not found";
	else if( 4 == err )
		ers = "Connection to device failed";
	else if( 8 == err )
		ers = "Device not connected";
	else if( 16 == err )
		ers = "Device already connected";
	else if( 32 == err )
		ers = "Incompatible PC";
	else if( 64 == err )
		ers = "Illegal parameter";
	else if( 256 == err )
		ers = "Send error";
	else if( 512 == err )
		ers = "Receive error";
	else if( 1024 == err )
		ers = "Received data not block data";
	else if( 4096 == err )
		ers = "System error";
	else if( 8192 == err )
		ers = "Illegal device ID";
	else
		ers = "";
	errMes.Format( "Error No.%d \n \"%s\"", err, ers );
	AfxMessageBox( (LPCTSTR)errMes, MB_OK | MB_ICONEXCLAMATION, 0 );
}

int GetTdiv( char* ans )
{
	char	*msg;									// Command buffer
	int		sts;
	int		rlen;


	msg = "TIMEBASE:TDIV 2ms";						// Set T/div = 2ms
	sts = TmcSend( Dev, msg );						// Send Command
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	msg = "TIMEBASE:TDIV?";							// Get T/div value
	sts = TmcSend( Dev, msg );						// Send Command
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	sts = TmcReceive( Dev, ans, (int)TEMP_BUFF_SIZE, &rlen );
													// Receive Query
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	ans[ rlen-1 ] = '\0';
	return sts;
}

int GetWord( char lst[][TEMP_BUFF_SIZE], int* cnt )
{
	char		*msg;								// Command buffer
	char		qry[TEMP_BUFF_SIZE];				// Query buffer
	CString		dlm;								// DL MODEL Number
	int			sts;
	double		vdv;								// Vdiv value
	double		ofs;								// Offset value
	double		div;								// Division Value
	int			dlg;								// Block Data Length
	double		dat;								// Data
	int			i;
	int			rLen;
	int			endflag;

	div = 3200;										// For DL9000 Series

	msg = "STOP";									// Stop Acquisition
	sts = TmcSend( Dev, msg );
    if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
    
    msg = "COMMUNICATE:HEADER OFF";					// Query Header Off(for Get V/div)
	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	msg = "WAVEFORM:TRACE 1";						// Trace = 1
	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
    
	msg = "WAVEFORM:RECORD 0";						// Record number = 0
	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

    msg = "WAVEFORM:FORMAT WORD";					// Data Format = WORD
	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	msg = "WAVEFORM:BYTEORDER LSBFIRST";			// Data Byte order = LSB First(for Little Endian)
	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

    msg = "WAVEFORM:START 0;END 124999";			// START 0,END 124999(Length = 125000)
	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	msg = "WAVEFORM:RANGE?";						// Get V/div value
	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	sts = TmcReceive( Dev, qry, TEMP_BUFF_SIZE, &rLen );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	vdv = atof( qry );

	msg = "WAVEFORM:OFFSET?";						// Get Offset value
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	sts = TmcReceive( Dev, qry, TEMP_BUFF_SIZE, &rLen );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	ofs = atof( qry );

	msg = "WAVEFORM:SEND?";							// Receive Waveform Data
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	sts = TmcReceiveBlockHeader( Dev, &dlg );		// Receive Block Header
	if( CTL_OK != sts ){							// dlg = Data Byte Length
		DisplayError( Dev );
		return sts;
	}
	sts = TmcReceiveBlockData( Dev, (char*)WaveBuffer, dlg + 1, &rLen, &endflag );
													// Receive Waveform Data + LF
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	for( i=0; i < ( dlg / 2 ); i++ ){
		dat = (double)(WaveBuffer[i]) * vdv / div + ofs;
		sprintf( lst[i], "%d:%f", i, dat );
	}
	*cnt = i;

	msg = "COMMUNICATE:HEADER ON";					// Query Header On
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	return sts;
}

int GetByte( char lst[][TEMP_BUFF_SIZE], int* cnt )
{
	char		*msg;								// Command buffer
	char		qry[TEMP_BUFF_SIZE];				// Query buffer
	int			sts;
	double		vdv;								// Vdiv value
	double		ofs;								// Offset value
	double		div;								// Division Value
	int			dlg;								// Block Data Length
	double		dat;								// Data
	int			i;
	int			rLen;
	int			endflag;


	div = 12.5;										// For DL9000 Series


	msg = "STOP";									// Stop Acquisition
	sts = TmcSend( Dev, msg );
    if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
    
    msg = "COMMUNICATE:HEADER OFF";					// Query Header Off(for Get V/div)
	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	msg = "WAVEFORM:TRACE 1";						// Trace = 1
	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
    
	msg = "WAVEFORM:RECORD 0";						// Record number = 0
	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

    msg = "WAVEFORM:FORMAT BYTE";					// Data Format = BYTE
	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

    msg = "WAVEFORM:START 0;END 124999";			// START 0,END 124999(Length = 125000)
	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	msg = "WAVEFORM:RANGE?";						// Get V/div value
	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	sts = TmcReceive( Dev, qry, TEMP_BUFF_SIZE, &rLen );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	vdv = atof( qry );

	msg = "WAVEFORM:OFFSET?";						// Get Offset value
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	sts = TmcReceive( Dev, qry, TEMP_BUFF_SIZE, &rLen );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	ofs = atof( qry );

	msg = "WAVEFORM:SEND?";							// Receive Waveform Data
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	sts = TmcReceiveBlockHeader( Dev, &dlg );		// Receive Block Header
	if( CTL_OK != sts ){							// dlg = Data Byte Length
		DisplayError( Dev );
		return sts;
	}
	sts = TmcReceiveBlockData( Dev, (char*)WaveBufferB, dlg + 1, &rLen, &endflag );
													// Receive Waveform Data + LF
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	for( i=0; i < dlg; i++ ){
		dat = WaveBufferB[i] * vdv / div + ofs;
		sprintf( lst[i], "%d:%f", i, dat );
	}
	*cnt = i;

	msg = "COMMUNICATE:HEADER ON";					// Query Header On
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	return sts;
}

int GetMeasure( char lst[][TEMP_BUFF_SIZE] )
{
	char		*msg;								// Command buffer
	char		qry[TEMP_BUFF_SIZE];				// Query buffer
	int			sts;
	int			stp;
	int			rLen;

	msg = "STOP";									// Acquisition = Stop
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	msg = "COMMUNICATE:HEADER OFF";					// Query Header Off(for Get V/div)
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	msg = "MEASURE:DISPLAY OFF";					// Measure Off
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	msg = "CHANNEL:DISPLAY ON";						// CH1 On
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
    
	msg = "CHANNEL:PROBE 10";						// CH1 Probe = 10:1
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	msg = "CHANNEL:VDIV 500mV";						// CH1 V/div = 500mV
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	msg = "ACQUIRE:MODE NORMAL;RLENGTH 125000";		// Acquisition mode = NORMAL, length = 125000
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	msg = "TIMEBASE:TDIV 1ms";						// T/div = 1ms
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	msg = "TRIGGER:SOURCE:CHANNEL1:LEVEL 500mV";	// Trigger level = 500mV
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	msg = "MEASURE:TRACE1:AREA1:PTOPEAK:STATE ON";	// Measure P-P On
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	msg = "MEASURE:TRACE1:AREA1:MEAN:STATE ON";		// Measure MEAN(Average) On
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	msg = "MEASURE:TRACE1:AREA1:FREQUENCY:STATE ON";
													// Measure FREQUENCY On
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
    
	msg = "MEASURE:TRANGE -5,5";					// Measure Time Range -5,5
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	msg = "SSTART? 500";							// Start Single Trigger
	sts = TmcSend( Dev, msg );						// Wait until stop Acquisition
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	sts = TmcReceive( Dev, qry, TEMP_BUFF_SIZE, &rLen );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	stp = atoi( qry );
	if( 1 == stp ){
		return MEAS_NOT_TRIG;						// Not TRIG'D
	}

	msg = "MEASURE:DISPLAY ON";						// Start Measure
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	msg = "MEASURE:WAIT? 100";						// Wait until stop Measure
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
 	sts = TmcReceive( Dev, qry, TEMP_BUFF_SIZE, &rLen );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	stp = atoi( qry );
	if( 1 == stp ){
		return MEAS_NOT_FIN;						// Measure not finish
	}

	msg = "MEASURE:TRACE1:AREA1:PTOPEAK:VALUE?";	// Get P-P value
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
 	sts = TmcReceive( Dev, qry, TEMP_BUFF_SIZE, &rLen );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	qry[ rLen-1 ] = '\0';
	sprintf( lst[0], "P-P:%s", qry );

	msg = "MEASURE:TRACE1:AREA1:MEAN:VALUE?";		// Get MEAN value
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
 	sts = TmcReceive( Dev, qry, TEMP_BUFF_SIZE, &rLen );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	qry[ rLen-1 ] = '\0';
	sprintf( lst[1], "Mean:%s", qry );

	msg = "MEASURE:TRACE1:AREA1:FREQUENCY:VALUE?";	// Get FREQ value
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
 	sts = TmcReceive( Dev, qry, TEMP_BUFF_SIZE, &rLen );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	qry[ rLen-1 ] = '\0';
	sprintf( lst[2], "Freq:%s", qry );

    msg = "COMMUNICATE:HEADER ON";					// Query Header On
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	return sts;
}

int PresetToGetWordRuntime( void )
{
	char		msg[TEMP_BUFF_SIZE];
	int			sts, i;

	strcpy( msg, "INITIALIZE:EXECUTE" );			// Initialize
	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	strcpy( msg, "ACQUIRE:RLENGTH 2500" );			// Set RecordLength = 2.5kpoints
	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	for( i=0; i<4; i++){

		sprintf( msg, "CHAN%d:PROBE 10", i+1 );		// Set CH Probe = 10:1
		sts = TmcSend( Dev, msg );
		if( CTL_OK != sts ){
			DisplayError( Dev );
			return sts;
		}

		sprintf( msg, "CHAN%d:VDIV 500mV", i+1 );	// Set CH V/Div = 500mV
		sts = TmcSend( Dev, msg );
		if( CTL_OK != sts ){
			DisplayError( Dev );
			return sts;
		}
	}

	strcpy( msg, "TIMEBASE:TDIV 500us" );			// Set T/div = 500us
	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	strcpy( msg, "TRIGGER:EDGE:LEVEL 500mV" );		// Set Trigger Level = 500mV
	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	strcpy( msg, "WAVEFORM:ALL:TRACE ALL" );		// Set Trace = ALL
	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	return CTL_OK;
}
int CheckDL6000_DLM6000( void )
{
	char		msg[TEMP_BUFF_SIZE];
	int			rlen;
	int			sts;
	char*		msgP;
	char*		modelP;

	strcpy( msg, "*IDN?" );								// Get Identification
	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
														// Receive Query
	sts = TmcReceive( Dev, msg, (int)TEMP_BUFF_SIZE, &rlen );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}
	msg[ rlen-1 ] = '\0';

	msgP=msg;
	while(*msgP){										// Search first comma
		if(','==*msgP)
			break;
		msgP++;
	}

	if('\0'==*msgP)
		return CTL_ERROR;

	msgP++;
	modelP=msgP;

	while(*msgP){										// Search second comma
		if(','==*msgP)
			break;
		msgP++;
	}

	if('\0'==*msgP)
		return CTL_ERROR;

	*msgP='\0';											// Terminate model string
	
	if( 0 != strcmp( "DL6054", modelP )
		&& 0 != strcmp( "DL6104", modelP )
		&& 0 != strcmp( "DL6154", modelP )
		&& 0 != strcmp( "DLM6054", modelP )
		&& 0 != strcmp( "DLM6104", modelP ))
		sts = CTL_ERROR;

	return CTL_OK;
}
int GetWordRuntime( char lst[][TEMP_BUFF_SIZE], int* cnt )
{
	char		msg[TEMP_BUFF_SIZE];
	unsigned	char	header[RUNTIME_HEADER_SIZE];
	int			sts;
	int			dlg;									// Block Data Length
	int			i;
	int			rLen;
	int			lfLen;
	int			endflag;
	int			traceNum;
	static		__int64 acqCount=0;
	int			dataLen;
	float		vReso;									// V/LSB 

	sprintf( msg, ":WAVEFORM:ALL:SEND? %d", acqCount );	// Receive Waveform Data while Runtime
   	sts = TmcSend( Dev, msg );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	sts = TmcReceiveBlockHeader( Dev, &dlg );			// Receive Block Header
	if( CTL_OK != sts ){								// dlg = Data Byte Length
		DisplayError( Dev );
		return sts;
	}
	if(( 0 == dlg )||( TEMP_DATA_LENGTH < dlg))
		return CTL_OK;
														// Receive Runtime Common Header
	sts = TmcReceiveBlockData( Dev, (char*)header, RUNTIME_COMMON_HEADER_SIZE, &rLen, &endflag );
	if( CTL_OK != sts ){
		DisplayError( Dev );
		return sts;
	}

	traceNum = header[0] + ( header[1] << 8 );			// Get Trace Number
														// Get ACQ Count
	acqCount = header[2] + ( header[3] << 8 ) + ( header[4] << 16 ) + ( header[5] << 24 )
				+ ( header[6] << 32 ) + ( header[7] << 40 ) + ( header[8] << 48 ) + ( header[9] << 56 );

	for( i=0; i < traceNum; i++ ){					
														// Receive Runtime Trace Header
		sts = TmcReceiveBlockData( Dev, (char*)header, RUNTIME_TRACE_HEADER_SIZE, &rLen, &endflag );
		if( CTL_OK != sts ){
			DisplayError( Dev );
			return sts;
		}											
														// Get Data Length
		dataLen = header[12] + ( header[13] << 8 ) + ( header[14] << 16 ) + ( header[15] << 24 );

		if( traceNum - 1 == i )							// for LF
			lfLen=1;
		else
			lfLen=0;

		sts = TmcReceiveBlockData( Dev, (char*)( WaveBuffer + dataLen * i ), dataLen * 2 + lfLen, &rLen, &endflag );
		if( CTL_OK != sts ){
			DisplayError( Dev );
			return sts;
		}
	}

	vReso=(float)0.5/3200;								// 500mV fix
	strcpy( lst[0], "No.,CH1(V),CH2(V),CH3(V),CH4(V)" );
	for( i = 0; i < dataLen; i++ )
		sprintf( lst[ i+1 ], "%d,%3.2f,%3.2f,%3.2f,%3.2f"
			, i, WaveBuffer[ i ] * vReso, WaveBuffer[i + dataLen ] * vReso
			, WaveBuffer[i + dataLen * 2 ] * vReso, WaveBuffer[i + dataLen * 3 ] * vReso );
	*cnt = i + 1;

	return CTL_OK;
}