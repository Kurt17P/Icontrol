C/C++ DEVQUERY Sample Application using Direct Entry

This directory contains the following:

     README.TXT           -  This readme file
     DLLDEVQUERY.C        -  C device-level direct entry sample
                             application

Description
-----------

The sample application uses direct entry to access the 32-bit GPIB DLL
instead of using one of the 32-bit language interfaces. The use of
direct entry means that the application takes the responsibility of
accessing the 32-bit GPIB DLL. Direct access to the 32-bit GPIB DLL
is accomplished by loading the DLL when the application is ready to use
it (using LoadLibrary), obtaining addresses of the global variables
and functions that the application needs to use (using GetProcAddress),
and finally, unloading the DLL (using FreeLibrary) before exiting.

This C sample application is a Win32 console application. It
illustrates how to use the NI-488.2 API. A Win32 console application
is a Win32 application which uses text-based input and output, not a
graphical interface. This allows you to quickly create a Win32
application by using simple input and output functions like printf and
scanf.


Choosing How to Access GPIB-32.DLL
----------------------------------

Applications can access GPIB-32.DLL by using either the Win32
Microsoft C/C++ language interface, the Win32 Borland C/C++ language
interface, the Win32 Microsoft Visual Basic language interface, or
direct entry. If you are using Microsoft C/C++, Borland C/C++, or
Microsoft Visual Basic, use the corresponding language interface to
develop your application. If you are using any other development
environment, you must use direct entry.


Compiling, Linking, and Running the Sample Application from the
Command Line
----------------------------------------------------------------

MICROSOFT VISUAL C/C++:

From the standard DOS shell command line, you can compile and link
the sample application, DllDevquery.c, using Microsoft Visual C/C++
(version 2.0 or higher), by typing in:

         cl DllDevquery.c

To run the application from the DOS shell, just type in the executable
name at the prompt. To run it from within Windows, choose the RUN...
option from the START menu. Enter the path and name of the compiled
application in the dialog box that pops up.


BORLAND C/C++:

From the standard DOS shell command line, you can compile and link
the sample application, DllDevquery.c, using Borland C/C++ (version 
4.0 or higher), by typing in:

         bcc32 -w32 DllDevquery.c

To run the application from the DOS shell, just type in the executable
name at the prompt. To run it from within Windows, choose the RUN...
option from the START menu. Enter the path and name of the compiled
application in the dialog box that pops up.


Creating Your Own Direct Entry NI-488.2 Application
---------------------------------------------------

Your application needs to include following two header files at the
beginning of your application:

#include <windows.h>
#include "ni488.h"

The 32-bit GPIB DLL exports pointers to the global variables and all
of the NI-488.2 functions and subroutines.  Pointers to the global
variables (ibsta, iberr, ibcnt and ibcntl) are accessible through
these exported variables:

        int  *user_ibsta;
        int  *user_iberr;
        int  *user_ibcnt;
        long *user_ibcntl;

Except for the functions explicitly listed below, all of the NI-488.2
calls are exported by the 32-bit GPIB DLL. What this means is that to
use direct entry to access a particular function (for example, ibwrt)
all you need to do to get a pointer to the exported function is to
call GetProcAddress passing the name of the function (for example,
"ibwrt") as a parameter. The parameters that you use when you invoke
the function are identical to those described in the Format C section
for the ibwrt function in the online help.

There are a few functions that the 32-bit GPIB DLL exports with
slightly different names. Here is a list of those functions:

        ibbna
        ibfind
        ibrdf
        ibwrtf

These functions all require an argument that is a name. ibbna requires
a board name (for example, "gpib0"), ibfind requires a board or device
name, and ibrdf and ibwrtf take a file name. Since Windows NT supports
both normal, 8-bit characters and Unicode, 16-bit wide characters,
GPIB-32.DLL exports two versions of each of these functions. An
"ASCII" version is for 8-bit characters (ibbnaA, ibfindA, ibrdA,
ibwrtA) and a "wide" version for 16-bit characters (ibbnaW, ibfindW,
ibrdW, ibwrtW). Neither Windows 98 nor Windows 95 supports wide
characters. So the only valid one to use is the 8-bit "ASCII" version.

To access any of these four functions in your application, you must
use the correct function name when calling GetProcAddress. For
Windows 98 or Windows 95 applications, use the 8-bit "ASCII" versions
named ibbnaA, ibfindA, ibrdfA, and ibwrtfA. For Unicode applications,
use the 16-bit wide versions named ibbnaW, ibfindW, ibrdfW, and
ibwrtfW.

At the beginning of your application, make sure that the following
lines are included:

   /* Pointers to NI-488.2 global status variables */
   int  *Pibsta;
   int  *Piberr;
   long *Pibcntl;

   /* Global variable for the handle to the loaded GPIB-32.DLL */
   HINSTANCE Gpib32Lib = NULL;

The prototypes for each function can be found in the online help.
For functions that return an integer value, like ibdev or ibwrt, the
pointer to the function needs to be cast as:

   int (__stdcall *Pname)

where *Pname is the name of the pointer to the function. For functions
that do not return a value, like FindLstn or SendList, the pointer to
the function needs to be cast as:

   void (__stdcall *Pname)

where *Pname if the name of the pointer to the function. They are
followed by the function's list of parameters as described in the
online help. Below is an example of how to cast the function pointer
and how the parameter list is set up for ibdev and ibonl functions:

int (__stdcall *Pibdev)(int ud, int pad, int sad, int tmo,
                        int eot, int eos);

int (__stdcall *Pibonl)(int ud, int v);

Within your application application, you need to load the GPIB-32.DLL
library. The example below shows you how to call the LoadLibrary
function along with a way to handle an error:

      Gpib32Lib = LoadLibrary("GPIB-32.DLL");
      if (!Gpib32Lib)
        return FALSE;

Next, your Win32 application needs to use GetProcAddress to get the
addresses of the global status variables and functions you need to
use. The following code fragment illustrates how to get the addresses
of the pointers to the status variables and any functions your
application needs to use:

      Pibsta  = (int *) GetProcAddress(Gpib32Lib,
                       (LPSTR)"user_ibsta");

      Piberr  = (int *) GetProcAddress(Gpib32Lib,
                       (LPSTR)"user_iberr");

      Pibcntl = (long *) GetProcAddress(Gpib32Lib,
                       (LPSTR)"user_ibcntl");

      Pibdev  = (int (__stdcall *) (int, int, int, int, int, int))
                 GetProcAddress(Gpib32Lib, (LPCSTR)"ibdev");

      Pibonl  = (int (__stdcall *) (int, int))GetProcAddress(Gpib32Lib,
                (LPCSTR)"ibonl");

If GetProcAddress fails, it returns a NULL pointer. The following code
fragment illustrates how to verify that none of the calls to
GetProcAddress failed:

      if ((Pibsta  == NULL) ||
          (Piberr  == NULL) ||
          (Pibcntl == NULL) ||
          (Pibdev  == NULL) ||
          (Pibonl  == NULL))
      {
        FreeLibrary(Gpib32Lib);
        Gpib32Lib = NULL;
        return FALSE;
      }
      else
        return TRUE;

Your Win32 application needs to dereference the pointer to access
either the status variables or functions. The following code
illustrates how to call a function and access the status variable
from within your application:

   dvm = (*Pibdev) (0, 1, 0, T10s, 1, 0);
   if (*Pibsta & ERR) Then
     printf("Call failed");

   (*Pibonl) (dvm, 0);

Upon completion of your application, free the library with the following:

   FreeLibrary(Gpib32Lib);


Compiling, Linking, and Running Your Direct Entry Win32 Application
-------------------------------------------------------------------

Before you compile your application, make sure that you have included
two header files at the beginning of your application:

#include <windows.h>
#include "ni488.h"


MICROSOFT VISUAL C/C++:

From the standard DOS shell command line, you can compile and link
your console application, using Microsoft Visual C/C++ (version 2.0 or
higher), by typing in:

         cl yourprog.c

To run the application from the DOS shell, just type in the executable
name at the prompt. To run it from within Windows, choose the RUN...
option from the START menu. Enter the path and name of the compiled
application in the dialog box that pops up.


BORLAND C/C++:

From the standard DOS shell command line, you can compile and link
your console application, using Borland C/C++ (version 4.0 or higher),
by typing in:

         bcc32 -w32 yourprog.c

To run the application from the DOS shell, just type in the executable
name at the prompt. To run it from within Windows, choose the RUN...
option from the START menu. Enter the path and name of the compiled
application in the dialog box that pops up.


More Information
----------------

Refer to the NI-488.2 online help for more information on application
development.



Copyright National Instruments Corporation.
All Rights Reserved.
