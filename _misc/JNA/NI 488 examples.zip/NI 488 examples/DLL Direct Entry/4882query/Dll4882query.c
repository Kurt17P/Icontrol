/* Filename - Dll4882query.c
 *
 *  This sample program is is comprised of three basic parts:
 *
 *  1. Initialization
 *  2. Main Body
 *  3. Cleanup
 *
 *  The Initialization portion consists of initializing the bus and the
 *  GPIB interface board so that the GPIB board is Controller-In-Charge
 *  (CIC). Next it finds all the listeners and then clears all the
 *  devices on the bus.
 *
 *  In the Main Body, this application queries all devices for their
 *  identification codes by issuing the '*IDN?' command. Many
 *  instruments respond to this command with an identification string.
 *  Note, 488.2 compliant devices are required to respond to this
 *  command.
 *
 *  The last step, Cleanup, takes the board offline.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

/*
 *  Include the WINDOWS.H and NI488.H files. The standard Windows
 *  header file, WINDOWS.H, contains definitions used by NI488.H and
 *  NI488.H contains prototypes for the GPIB routines and constants.
 */
#include <windows.h>
#include "..\\ni488.h"

#define ARRAYSIZE  100                 // Size of read buffer
#define GPIB0        0                 // Board handle

int        loop,                       // Loop counter
           Num_Listeners;              // Number of listeners on GPIB
Addr4882_t Instruments[32],            // Array of primary addresses
           Result[31];                 // Array of listen addresses
char       ReadBuffer[ARRAYSIZE + 1];  // Read data buffer
char ErrorMnemonic[21][5] = {"EDVR", "ECIC", "ENOL", "EADR", "EARG",
                             "ESAC", "EABO", "ENEB", "EDMA", "",
                             "EOIP", "ECAP", "EFSO", "", "EBUS",
                             "ESTB", "ESRQ", "", "", "", "ETAB"};

void GPIBCleanup(int ud, char* ErrorMsg);


/****************************************
 ********  CODE TO ACCESS GPIB-32.DLL
 ***********************************************/

static void (__stdcall *PDevClearList)(int boardID, Addr4882_t * addrlist);
static void (__stdcall *PFindLstn)(int boardID, Addr4882_t * addrlist, PSHORT results, int limit);
static int  (__stdcall *Pibonl)(int ud, int v);
static void (__stdcall *PReceive)(int boardID, Addr4882_t addr, PVOID buffer, LONG cnt, int Termination);
static void (__stdcall *PSendList)(int boardID, Addr4882_t * addrlist, PVOID databuf, LONG datacnt, int eotMode);
static void (__stdcall *PSendIFC)(int boardID);

/*
 *    This is private data for the language interface only so it is
 *    defined as 'static'.
 */
static HINSTANCE Gpib32Lib = NULL;
static int *Pibsta;
static int *Piberr;
static long *Pibcntl;


static BOOLEAN LoadDll (void)
{
   /*
    *  Call LoadLibrary to load the 32-bit GPIB DLL.  Save the handle
    *  into the global 'Gpib32Lib'.
    */
   Gpib32Lib = LoadLibrary ("GPIB-32.DLL");

   if (!Gpib32Lib)  {
      /*
       *    The LoadLibrary call failed, return with an error.
       */
      return FALSE;
   }


   /*
    *    OK, the GPIB library is loaded.  Let's get a pointer to the
    *    requested function.  If the GetProcAddress call fails, then
    *    return with an error.
    */
   Pibsta          = (int *) GetProcAddress(Gpib32Lib, (LPCSTR)"user_ibsta");
   Piberr          = (int *) GetProcAddress(Gpib32Lib, (LPCSTR)"user_iberr");
   Pibcntl         = (long *)GetProcAddress(Gpib32Lib, (LPCSTR)"user_ibcnt");

   PDevClearList   = (void (__stdcall *)(int, Addr4882_t *))GetProcAddress(Gpib32Lib, (LPCSTR)"DevClearList");
   PFindLstn       = (void (__stdcall *)(int, Addr4882_t *, PSHORT, int))GetProcAddress(Gpib32Lib, (LPCSTR)"FindLstn");
   Pibonl          = (int  (__stdcall *)(int, int))GetProcAddress(Gpib32Lib, (LPCSTR)"ibonl");
   PReceive        = (void (__stdcall *)(int, Addr4882_t, PVOID, LONG, int))GetProcAddress(Gpib32Lib, (LPCSTR)"Receive");
   PSendList       = (void (__stdcall *)(int, Addr4882_t *, PVOID, LONG, int))GetProcAddress(Gpib32Lib, (LPCSTR)"SendList");
   PSendIFC        = (void (__stdcall *)(int))GetProcAddress(Gpib32Lib, (LPCSTR)"SendIFC");


   if ((Pibsta         == NULL) ||
       (Piberr         == NULL) ||
       (Pibcntl        == NULL) ||
       (PDevClearList  == NULL) ||
       (PFindLstn      == NULL) ||
       (Pibonl         == NULL) ||
       (PReceive       == NULL) ||
       (PSendList      == NULL) ||
       (PSendIFC       == NULL))  {

      FreeLibrary (Gpib32Lib);
      Gpib32Lib = NULL;
      return FALSE;
   }
   else  {
      return TRUE;
   }

}  /* end of LoadDll */


static void FreeDll (void)
{
   FreeLibrary (Gpib32Lib);
   Gpib32Lib = NULL;
   return;
}


int __cdecl main() {

    if (!LoadDll())  {
       printf ("Unable to correctly access the 32-bit GPIB DLL.\n");
       return 1;
    }

/* ====================================================================
 *
 *  INITIALIZATION SECTION
 *
 * ====================================================================
 */

/*
 *  Your board needs to be the Controller-In-Charge in order to find all
 *  listeners on the GPIB.  To accomplish this, the function SendIFC is
 *  called. If the error bit ERR is set in ibsta, call GPIBCleanup with
 *  an error message.
 */

    (*PSendIFC)(GPIB0);
    if ((*Pibsta) & ERR)
    {
       GPIBCleanup(GPIB0, "Unable to open board");
       return 1;
    }

/*
 *  Create an array containing all valid GPIB primary addresses,
 *  except for primary address 0.  Your GPIB interface board is at
 *  address 0 by default.  This array (Instruments) will be given to
 *  the function FindLstn to find all listeners.  The constant NOADDR,
 *  defined in NI488.H, signifies the end of the array.
 */

    for (loop = 0; loop < 30; loop++) {
       Instruments[loop] = (Addr4882_t)(loop + 1);
    }
    Instruments[30] = NOADDR;

/*
 *  Print message to tell user that the program is searching for all
 *  active listeners.  Find all of the listeners on the bus.  Store
 *  the listen addresses in the array Result. If the error bit ERR is
 *  set in ibsta, call GPIBCleanup with an error message.
 */

    printf("Finding all listeners on the bus...\n\n");

    (*PFindLstn)(GPIB0, Instruments, Result, 31);
    if ((*Pibsta) & ERR)
    {
       GPIBCleanup(GPIB0, "Unable to issue FindLstn call");
       return 1;
    }

/*
 *  ibcntl contains the actual number of addresses stored in the
 *  Result array. Assign the value of ibcntl to the variable
 *  Num_Listeners. Print the number of listeners found.
 */

    Num_Listeners = (short)(*Pibcntl);

    printf("Number of instruments found = %d\n\n", Num_Listeners);

/*
 *  The Result array contains the addresses of all listening devices
 *  found by FindLstn. Use the constant NOADDR, as defined in
 *  NI488.H, to signify the end of the array.
 */

    Result[Num_Listeners] = NOADDR;

/*
 *  DevClearList will send the GPIB Selected Device Clear (SDC)
 *  command message to all the devices on the bus.  If the error bit
 *  ERR is set in ibsta, call GPIBCleanup with an error message.
 */

    (*PDevClearList)(GPIB0, Result);
    if ((*Pibsta) & ERR)
    {
       GPIBCleanup(GPIB0, "Unable to clear devices");
       return 1;
    }

/* ====================================================================
 *
 *  MAIN BODY SECTION
 *
 *  In this application, the Main Body communicates with the
 *  instruments by writing a command to them and reading the individual
 *  responses. This would be the right place to put other instrument
 *  communication.
 *
 * ====================================================================
 */

/*
 *  Send the identification query to each listen address in the array
 *  (Result) using SendList.  The constant NLend, defined in NI488.H,
 *  instructs the function SendList to append a linefeed character
 *  with EOI asserted to the end of the message.  If the error bit ERR
 *  is set in ibsta, call GPIBCleanup with an error message.
 */

    (*PSendList)(GPIB0, Result, "*IDN?", 5L, NLend);
    if ((*Pibsta) & ERR)
    {
       GPIBCleanup(GPIB0, "Unable to write to devices");
       return 1;
    }

/*
 *  Read each device's identification code, one at a time.
 *
 *  Establish a FOR loop to read each one of the device's
 *  identification code. The variable LOOP will serve as a counter
 *  for the FOR loop and as the index to the array Result.
 */

    for (loop = 0; loop < Num_Listeners; loop++)
    {
       /*
        *  Read the name identification response returned from each
        *  device. Store the response in the array ReadBuffer.  The
        *  constant STOPend, defined in NI488.H, instructs the
        *  function Receive to terminate the read when END is detected.
        *  If the error bit ERR is set in ibsta, call GPIBCleanup with
        *  an error message.
        */

           (*PReceive)(GPIB0, Result[loop], ReadBuffer, ARRAYSIZE, STOPend);
           if ((*Pibsta) & ERR)
           {
              GPIBCleanup(GPIB0, "Unable to read from a device");
              return 1;
           }

       /*
        *  Assume that the returned string contains ASCII data. NULL
        *  terminate the string using the value in ibcntl which is
        *  the number of bytes read in. Use printf to display the
        *  string.
        */

           ReadBuffer[(*Pibcntl)] = '\0';
           printf("Returned string: %s", ReadBuffer);

    }      /*  End of FOR loop */

/* ====================================================================
 *
 *  CLEANUP SECTION
 *
 * ====================================================================
 */

/*  Take the board offline.                                                 */

    (*Pibonl) (GPIB0, 0);

    FreeDll();
}


/*
 *  After each GPIB call, the application checks whether the call
 *  succeeded. If an NI-488.2 call fails, the GPIB driver sets the
 *  corresponding bit in the global status variable. If the call
 *  failed, this procedure prints an error message, takes the board
 *  offline and exits.
 */
void GPIBCleanup(int ud, char* ErrorMsg)
{
    printf("Error : %s\nibsta = 0x%x iberr = %d (%s)\n",
            ErrorMsg, *Pibsta, *Piberr, ErrorMnemonic[(*Piberr)]);
    printf("Cleanup: Taking board offline\n");
    (*Pibonl) (ud, 0);

    FreeDll();

}
